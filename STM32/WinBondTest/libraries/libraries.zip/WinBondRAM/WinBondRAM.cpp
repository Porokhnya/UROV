#include "WinBondRAM.h"
#include<SPIFlash.h>


//----------------------------------------------------------------------------
void WinBondRAM::begin(SPIFlash& _flash) 
{
	flash = &_flash;
}
//----------------------------------------------------------------------------
bool WinBondRAM::read(uint32_t address, void *buf, size_t nbyte) 
{
  
  if(!flash)
  {
	  return false;
  }
  
  
//ТУТ КОД ЧТЕНИЯ ИЗ ПАМЯТИ
// bool     readByteArray(uint32_t _addr, uint8_t *data_buffer, size_t bufferSize, bool fastRead = false);
return flash->readByteArray(address, (uint8_t*)buf, nbyte);


}
//----------------------------------------------------------------------------
bool WinBondRAM::write(uint32_t address, const void *buf, size_t nbyte) 
{
  if(!flash)
  {
	  return false;
  }
  
 // Serial.print("WinBondRAM::write, addr=");
 // Serial.print(address);
 // Serial.print(", buf size=");
 // Serial.println(nbyte);

  
//ТУТ КОД ЗАПИСИ В ПАМЯТЬ
// bool     writeByteArray(uint32_t _addr, uint8_t *data_buffer, size_t bufferSize, bool errorCheck = true);
bool b = flash->writeByteArray(address,(uint8_t*)buf,nbyte);

//if(b)
//{
//	Serial.println("WinBondRAM::write, OK.");
//}
//else
//{
//	Serial.println("WinBondRAM::write, WRITE ERROR!");
//}

return b;
}
//----------------------------------------------------------------------------

