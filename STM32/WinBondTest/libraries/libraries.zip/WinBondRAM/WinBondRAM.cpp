#include "WinBondRAM.h"
//----------------------------------------------------------------------------
void WinBondRAM::begin(uint8_t _pin, uint8_t _mosi, uint8_t _miso, uint8_t _sck) 
{

	SPI.stm32SetMOSI(_mosi);
	SPI.stm32SetMISO(_miso);
	SPI.stm32SetSCK(_sck);
	
	delete flash;
	flash = new SPIFlash(_pin);
   
   //ТУТ ИНИЦИАЛИЗАЦИЯ ПАМЯТИ
   flash->begin();
   
}
//----------------------------------------------------------------------------
bool WinBondRAM::read(uint32_t address, void *buf, size_t nbyte) 
{
  
//ТУТ КОД ЧТЕНИЯ ИЗ ПАМЯТИ
// bool     readByteArray(uint32_t _addr, uint8_t *data_buffer, size_t bufferSize, bool fastRead = false);
return flash->readByteArray(address, (uint8_t*)buf, nbyte);
}
//----------------------------------------------------------------------------
bool WinBondRAM::write(uint32_t address, const void *buf, size_t nbyte) 
{

//ТУТ КОД ЗАПИСИ В ПАМЯТЬ
// bool     writeByteArray(uint32_t _addr, uint8_t *data_buffer, size_t bufferSize, bool errorCheck = true);
return flash->writeByteArray(address,(uint8_t*)buf,nbyte,false);
}
//----------------------------------------------------------------------------
