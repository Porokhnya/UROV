#pragma once
//----------------------------------------------------------------------------
#include <Arduino.h>
#include <RamBaseDevice.h>
#include<SPIFlash.h>


class WinBondRAM : public RamBaseDevice 
{
	private:
		SPIFlash* flash = NULL; // наша память на SPI
			
 public:
  // инициализация памяти WinBond
  void begin(uint8_t pin, uint8_t mosi, uint8_t miso, uint8_t sck);
  //----------------------------------------------------------------------------
  /** Читаем блок из памяти
   * \param[in] address - адрес в памяти для чтения
   * \param[out] buf - выходной буфер
   * \param[in] nbyte - кол-во байт в выходном буфере
   * \return всегда возвращает true.
   */
  bool read(uint32_t address, void *buf, size_t nbyte); 

  //----------------------------------------------------------------------------
 /**
   * \return возвращает общее количество блоков по 512 байт в используемой памяти.
   */  
   uint32_t sizeBlocks() 
   {
	  
	  return 256; // 256 блоков по 512 байт = 128 Килобайт, для примера
	}
  //----------------------------------------------------------------------------
  /** Пишет блок в микросхему.
   * \param[in] address - адрес в памяти, по которому писать.
   * \param[in] buf - входной буфер.
   * \param[in] nbyte - кол-во байт во входом буфере
   * \return всегда возвращает true.
   */
  bool write(uint32_t address, const void *buf, size_t nbyte);

 
};
//----------------------------------------------------------------------------
