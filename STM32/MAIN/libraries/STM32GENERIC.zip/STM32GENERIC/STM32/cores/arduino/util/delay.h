//AVR compatibility functions

#define _delay_us(n) delayMicroseconds(n)

#define _delay_ms(n) delay(n)
