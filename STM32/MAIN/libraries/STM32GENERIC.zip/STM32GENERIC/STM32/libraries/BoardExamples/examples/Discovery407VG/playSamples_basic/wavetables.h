#define MAXVALUE 255
#define SONGLEN 6442

extern const uint8_t sabine[];
extern const uint8_t piano[];

