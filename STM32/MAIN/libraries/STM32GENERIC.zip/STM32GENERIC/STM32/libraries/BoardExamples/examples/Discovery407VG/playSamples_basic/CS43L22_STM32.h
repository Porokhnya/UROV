
#include <Wire.h>

class CS43L22_STM32
{
  public:
    CS43L22_STM32();
    void begin();
};

