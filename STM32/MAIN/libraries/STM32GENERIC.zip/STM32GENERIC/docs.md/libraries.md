TODO automatically compile all libraries, and show results here
