Description
---

A simple **XPT2046** Touch Screen library for STM32duino project (http://stm32duino.com)

Tested on "BluePill"